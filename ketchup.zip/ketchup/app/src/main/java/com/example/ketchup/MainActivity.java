package com.example.ketchup;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;


public class MainActivity extends AppCompatActivity {

    public static final String EXTRA_MESSAGE = "com.example.ketchup.MESSAGE";
    public static final int daysInMilli = 1000*60*60*24;
    int contactFrequency = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }


    public int countDays (int contactFrequency, Date lastContact){
        Date today = new Date();
        long today_time = today.getTime();
        long lastContact_time = lastContact.getTime();
        long timePassed = (today_time - lastContact_time)/daysInMilli;
        int daysToNextContact = (int) (contactFrequency - timePassed);
        return daysToNextContact;
    }

    public void updateCountdown (TextView countDownText, TextView dayWeekMonthText, int daysToNextContact){
        if (daysToNextContact < 7){
            countDownText.setText(Integer.toString(daysToNextContact));
            if (daysToNextContact == 1) { dayWeekMonthText.setText("day"); }
            else { dayWeekMonthText.setText("days"); }
            return;
        }
        int weeksToNextContact = daysToNextContact/7;
        if (daysToNextContact < 30){
            countDownText.setText(Integer.toString(weeksToNextContact));
            if (weeksToNextContact == 1) { dayWeekMonthText.setText("week"); }
            else { dayWeekMonthText.setText("weeks"); }
            return;
        }
        int monthsToNextContact = daysToNextContact/30;
        if (daysToNextContact < 365){
            countDownText.setText(Integer.toString(monthsToNextContact));
            if (monthsToNextContact == 1) { dayWeekMonthText.setText("month"); }
            else { dayWeekMonthText.setText("months"); }
            return;
        }
        int yearsToNextContact = daysToNextContact/365;
        countDownText.setText(Integer.toString(yearsToNextContact));
        if (yearsToNextContact == 1) { dayWeekMonthText.setText("year"); }
        else { dayWeekMonthText.setText("years"); }
    }

    public void updateEntryColor(RelativeLayout contactEntry, int daysToNextContact){

        if (daysToNextContact == 0) {
            contactEntry.setBackgroundColor(0xFFFFFAC9);
            return;
        }

        if (daysToNextContact < 0) {
            contactEntry.setBackgroundColor(0x80FF0000);
            return;
        }

        int R = Math.round(Math.max(255 - 2*daysToNextContact,0));
        int G = Math.round(Math.max(255 - 20*daysToNextContact,0));
        int B = Math.round(Math.min(8*daysToNextContact, 255));

        R = (R << 16) & 0x00FF0000;
        G = (G << 8) & 0x0000FF00;
        B = B & 0x000000FF;

        contactEntry.setBackgroundColor(0xFF000000 | R | G | B);
    }

    public void goToAddContact(View view) {
        startActivity(new Intent(this,AddContactActivity.class));
    }

    public void test(View view) throws ParseException {
        RelativeLayout contactEntry = (RelativeLayout) findViewById(R.id.contact_entry);
        TextView countDownTextBox = (TextView) findViewById(R.id.countdown_text);
        TextView dayWeekMonthTextBox = (TextView) findViewById(R.id.dwm_text);
        Date lastContact = new SimpleDateFormat("yyyy-MM-dd").parse("2021-02-01");
        int daysToNextContact = countDays(contactFrequency, lastContact);
        updateCountdown(countDownTextBox, dayWeekMonthTextBox, daysToNextContact);
        updateEntryColor(contactEntry, daysToNextContact);
        contactFrequency += 2;
    }
}