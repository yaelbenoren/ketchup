package com.example.ketchup;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

public class AddContactActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_contact);
        setDropdown();
    }

    public void setDropdown() {
        //get the spinner from the xml.
        Spinner dropdown = findViewById(R.id.dwm_dropdowm);
        //create a list of items for the spinner.
        String[] items = new String[]{"days", "weeks", "months", "years"};
        //create an adapter to describe how the items are displayed, adapters are used in several places in android.
        //There are multiple variations of this, but this is the basic variant.
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, items);
        //set the spinners adapter to the previously created one.
        dropdown.setAdapter(adapter);
    }

    public void fillContact(View view){
        Spinner dwmDropdown = findViewById(R.id.dwm_dropdowm);
        EditText nameEditText = findViewById(R.id.edit_contact_name);
        EditText lastContactEditText = findViewById(R.id.edit_last_contact_date);
    }
}